{-# LANGUAGE OverloadedStrings #-}

module Main where

import Web.Scotty
import Network.Wai.Middleware.Static

main :: IO ()
main = scotty 3001 (
  middleware (staticPolicy (addBase "public")) >>

  get "/greet/:name" (captureParam "name" >>= \name -> text ("Hello, " <> name <> "!")) >>
  get "/hello" (text "shalom") >>

  -- Serve HTML

  get "/first" (file "html1.html")
  )
