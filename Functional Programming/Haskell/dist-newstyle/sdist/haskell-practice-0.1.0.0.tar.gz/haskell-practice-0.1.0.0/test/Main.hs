module Main (main) where

main :: IO ()
main = putStrLn "Test suite not yet implemented."
