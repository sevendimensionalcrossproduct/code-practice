module MyLib where

import Language.Haskell.TH
import Language.Haskell.TH.Syntax
import Control.Monad

main = do
 putStrLn "Hi"
